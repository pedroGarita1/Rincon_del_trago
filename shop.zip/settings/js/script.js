var valor = "Project bar";
